package simpackage;
import java.awt.Color;
/**
 * @author (psalmjrel) 
 * @version (19/06/17)
 */
public class Metal
{
	private boolean thresholdFrequencyMet;
	
    private String metalSymbol;
    private String metalName;
    private Color clr;
    private double metalWorkF;
    private double atomicWeight;
    private int protonNumber;    
    public Metal(){
        //default constructor
    }
    
    public Metal(String metalSymbol, String metalName,Color clr, double metalWorkF, double atomicWeight, int protonNumber){
        this.metalSymbol = metalSymbol;
        this.metalName = metalName;
        this.clr = clr;
        this.metalWorkF = metalWorkF;
        this.atomicWeight = atomicWeight;
        this.protonNumber = protonNumber;


    }
    
    //GETTERS AND SETTERS
    public String getMetalSymbol(){
        return this.metalSymbol;
    }
    
    public void setMetalSymbol(String m) {
    	this.metalSymbol= m;
    }
    
    public Color getColour(){
        return this.clr;
    }
    
    public void setColor(Color c) {
    	this.clr = c;
    }

    public String getMetalName(){
        return this.metalName;
    }
    
    public void setMetalName(String mn) {
    	this.metalName = mn;
    }

    public double getMetalWorkF(){
        return this.metalWorkF;
    }
    
    public void setMetalWorkF(String f) {
    	this.metalWorkF = Double.parseDouble(f);
    }

    public double getAtomicWeight(){
        return this.atomicWeight;
    }
    
    public void setAtomicWeight(String a) {
    	this.atomicWeight = Double.parseDouble(a);
    }

    public int getProtonNumber(){
        return this.protonNumber;
    }
    
    public void setProtonNumber(String p) {
    	this.protonNumber = Integer.parseInt(p);
    }


    //parameters take in the photon energy and the work function of metal
    //the threshold frequency is met if photon energy is bigger than work function
    public boolean thresholdFrequencyMet(double photonE, double workF) {
        if (photonE >= workF) {
            this.thresholdFrequencyMet = true;
        } else {
            this.thresholdFrequencyMet = false;
        }
        return this.thresholdFrequencyMet;
    }
    
    public void setThreshOldFrequencyMet(boolean b) {
    	this.thresholdFrequencyMet = b;
    }

    
    public boolean getThreshOldFrequencyMet() {
    	return thresholdFrequencyMet;
    }

    public String toString(){
        return "Name of Metal: "+metalName+"\nSymbol in Periodic Table: "+metalSymbol+"\nAtomic Weight: "+atomicWeight+"\nProton Number: "+protonNumber+"\nWork Function(eV): "+metalWorkF;
    }

}
