package simpackage;
import javax.swing.*;
import java.awt.*;

/**
 * @author (psalmjrel)
 */

public class PaintElectron extends JComponent
{
    // instance variables 
	private boolean paused = false;
	private boolean beamIsOn, thresholdFMet;
	
	private PhotoElectron[] peArray;	//array of photoelectrons
    private GUI view;
    
    private final int basePhotonsAmount = 15;	//default amount of eletrons travelling
    private int photonsAmountCoeff = 1;	//coeff, will vary depending on intensity
    

    //default contrusctor
    public PaintElectron(GUI gui) {
    	this.view = gui;
    	
    	peArray = new PhotoElectron[basePhotonsAmount*photonsAmountCoeff];	//creates an array of PhotoElectron class
    	
        for(int i=0; i< peArray.length; i++){	//creates PhotoElectrons and stores in array
            peArray[i] = new PhotoElectron();
        } 
        
    	updateGUI(view);
    }
    
    public void updatePaintElectron(GUI gui) {	//method to update PhotoElectrons
    	this.view = gui;
    	
    	peArray = new PhotoElectron[basePhotonsAmount*photonsAmountCoeff];
    	
    	
        for(int i=0; i< peArray.length; i++){
            peArray[i] = new PhotoElectron();
        } 
        
    	updateGUI(view);
    }
    

    
    public void move(JPanel p){	//moves electrons
    	
    	
        p.setBackground(Color.WHITE);	//sets background white
        
        if(beamIsOn && thresholdFMet) {	//checks if beam is on and threshold is met
        	
        	for(PhotoElectron peArrayA : peArray){	//creates photoelectrons
        		try {
        			peArrayA.setAnimationState(paused);
        			peArrayA.create(p);
        		}catch(Exception E) {}
        	}
        }
        
    }
    
    public void setPaused(boolean paused) {
    	this.paused = paused;
    }
    
    public PhotoElectron[] getPhotoElectronArray() {
    	return this.peArray;
    }
    
    //sets coeff to increase or decrease amount of photoelectrons
    public void setPhotonsAmountCoeff(int n) {
    	this.photonsAmountCoeff = n;
    }
    
    public void updateGUI(GUI v) {	//method to start thread
    	JPanel p = v.getElectronCanvas();
    	 Thread animationThread = new Thread(new Runnable() {
             public void run() {
                 while (true) {
                 	
                     SwingUtilities.invokeLater(new Runnable(){
                  	   @Override
                  	   public void run() {
                  		   move(p);
                  	   }
                     });                 	
                 	
                     try {Thread.sleep(10);} catch (Exception ex) {}
                 }
             }
         });

         animationThread.start();

    }
    
    public void checkBeam(boolean b) {	//checks state of beam
    	
           this.beamIsOn = b;
    }
    
    public void isthreshFreqMet(boolean b) {	//checks if threshold is met
    	this.thresholdFMet = b;
    }
    
}
 