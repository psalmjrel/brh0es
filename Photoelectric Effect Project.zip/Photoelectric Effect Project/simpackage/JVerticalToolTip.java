package simpackage;
import java.awt.*;  
import javax.swing.*;
  
public class JVerticalToolTip extends JToolTip {
    private static final long serialVersionUID = 1L;
    private JTextPane textPane;
     
    /** Creates a tool tip. */
    public JVerticalToolTip(final int width, final int height) {
        setPreferredSize(new Dimension(width, height));
        setLayout(new BorderLayout());
        textPane = new JTextPane();
        textPane.setEditable(true);
        textPane.setContentType("text");
         
        LookAndFeel.installColorsAndFont(textPane, 
                "ToolTip.background",
                "ToolTip.foreground",
                "ToolTip.font");
            
        JScrollPane scrollpane = new JScrollPane(textPane);
        scrollpane.setBorder(null);
        scrollpane.getViewport().setOpaque(false);
        add(scrollpane);
    }
     

  
    @Override
    public void setTipText(final String tipText) {
        String oldValue = this.textPane.getText();
        textPane.setText(tipText);
        textPane.setCaretPosition(0);
        firePropertyChange("tiptext", oldValue, tipText);
    }
  
    @Override
    public String getTipText() {
        return textPane == null ? "" : textPane.getText();
    }
  
    @Override
    protected String paramString() {
        String tipTextString = (textPane.getText() != null ? textPane.getText() : "");
  
        return super.paramString()
                + ",tipText=" + tipTextString;
    }
  
}