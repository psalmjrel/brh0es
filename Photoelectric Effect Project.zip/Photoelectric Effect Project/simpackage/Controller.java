package simpackage;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * @author (psalmjrel)
 */
public class Controller implements ActionListener, ChangeListener
{
	
	private boolean beamIsOn;    //checker for state of beam
    private boolean thresholdFMet;    //checked if threshold frequency is met

	
    private GUI view;
    private Metal metal;
    private Handler h = new Handler();
    private Beam beam = new Beam();
    private Calculations calc = new Calculations(beam);
    private PaintElectron electronStream;
    private String[][] metalsArray;	//2d array for metal and its attributes

    
        //constructor for controller, the gui created from GUI class is a parameter 
        //to be able to maniipulate componenets, the same with PaintElectron
    public Controller(GUI gui,  Metal metal){
        this.view = gui;
        this.metal = metal;
        electronStream  = new PaintElectron(view);	//initialises stream of electrons
        view.getElectronCanvas().add(electronStream, BorderLayout.CENTER);	//adds to canvas
        setUpArray(); 	//method to set up the 2d array       
    }

	public void actionPerformed(ActionEvent ae){
        Object source = ae.getSource();    //checks what component was fired

        if(source instanceof JButton){    //if its a button
        	int n = 0;
        	JButton btn = (JButton) source;    //the source button is held
        	if(btn.getActionCommand().equalsIgnoreCase("reset")) {    
        		view.getElectronCanvas().removeAll();
        		reload();
                resetValues();    //resets the valus
                
        	}else if(btn.getActionCommand().equalsIgnoreCase("pause")) {	//simulation paused
        		electronStream.setPaused(true);
        		
        	}else if(btn.getActionCommand().equalsIgnoreCase("resume")){	//simulation resumed
        		electronStream.setPaused(false);
        		
        	}else if(btn.getActionCommand().equalsIgnoreCase("off.")) {    //button to turn beam off
        		view.getTextFieldIntensity().setText("0");
        		view.getSliderIntensity().setValue(0);
        		beamIsOn = false;    //beam is off
        		beamOff();    //componenets from GUI respond accordingly
        		
        	}else if(btn.getActionCommand().equalsIgnoreCase("100%")) {    //button to set intensity to 100%
        		n = 1;
        		view.getTextFieldIntensity().setText("100");
        		view.getSliderIntensity().setValue(100);    //sets to 100%
        		beamIsOn = true;    //
        		electronStream.setPhotonsAmountCoeff(n);
        		updatePaintElectron(view, n);

        	}else if(btn.getActionCommand().equalsIgnoreCase("200%")) {
        		n = 2;
        		view.getTextFieldIntensity().setText("200");
        		view.getSliderIntensity().setValue(200);
        		beamIsOn = true;
        		electronStream.setPhotonsAmountCoeff(n);
        		updatePaintElectron(view, n);


        		
        	}else if(btn.getActionCommand().equalsIgnoreCase("300%")) {
        		n = 3;
        		view.getTextFieldIntensity().setText("300");
        		view.getSliderIntensity().setValue(300);
        		beamIsOn = true;
        		electronStream.setPhotonsAmountCoeff(n);
        		updatePaintElectron(view, n);

        		
        	}
        	reload();
        	setValues(view.getTextFieldVal().getText(), beamIsOn);	//updates values
        	
        	
        }else if(source instanceof JTextField){    // a value is entered into textfield
            String value = view.getTextFieldVal().getText();    //stores the value from text field

            int valueInt = Integer.parseInt(value);    //text from a textfield is string, so turned  it to integer
            									       //so calcualtions can occur
            
            view.getSliderWaveLength().setValue(valueInt);    //the slder and textfield are connected

            setValues(value, beamIsOn);    //sets the values of components according to calculations that take place
            							    //boolean 'beamIsOn' is a paramaeter, calculations will occur if true
            
        }else if(source instanceof JComboBox) {	//a metal is selected
        	boolean searchingDone = false;	//checks if searching is done
        	int i = 0;
        	JComboBox<?> cb = (JComboBox<?>) source;	//casts the source into of type JComboBox
        	String selected = (String) cb.getSelectedItem();	//gets the selected item
        	
        	while(!searchingDone) {	//will search if not done
        		if(selected!=null) {	//a metal is selected
        			if(selected.equalsIgnoreCase((String)metalsArray[i][1])) {	//index 1 in column is the name of the Metal, a match occurs
        				this.metal.setMetalSymbol((String)metalsArray[i][0]);	//index 0 is metal symbol
        				this.metal.setMetalName(selected);
        				this.metal.setColor(setMetalColor((String)metalsArray[i][2]));	//index 2 is colour of metal
        																				//setMetalColor() is a function that returns of type Color to determine the Color of metal
        																				//to be able to set the color of button
        				this.metal.setMetalWorkF((String)metalsArray[i][3]);	//index 3 is work function
        				this.metal.setAtomicWeight((String)metalsArray[i][4]);	//index 4 is atomic weight
        				this.metal.setProtonNumber((String)metalsArray[i][5]);	//index 5 is proton number
        			
        				view.getMetalPlateLbl().setText(metal.getMetalName());	//sets the label to be the metal selected
        				view.getMetalPlateLbl().setForeground(Color.BLUE);
        				view.getMetalPlateBtn().add(view.getMetalPlateLbl());
        				view.getMetalPlateBtn().setBackground(metal.getColour());
        				view.getMetalPlateBtn().setToolTipText(metal.toString());	//user can view metal attributes by hovering mouse
        				view.getMetalPlateBtn().setEnabled(false);
        				
        				searchingDone = true;	//searching is done
        				
        			}else if(!(selected.equalsIgnoreCase((String)metalsArray[i][1]))) {	//index [i][1] is not a match, inc i
        				i++;	//does a linear search
        			}
        			
    
        		}else if(selected==null) {	//no metal is selected, values reset
    				this.metal.setProtonNumber("-1"); //rogue value -1, informing other methods that refer to the Metal class that metal has not been selected
        			searchingDone = true;
        			resetValues();
        			reload();
        		}
        	}
        	calc.setMetal(this.metal);	//initialises the type of metal plate
        	
        }
        electronStream.checkBeam(beamIsOn);    //the stream of electrons checks if beam is on,
        									    //if true, then paints electrons
        setValues(view.getTextFieldVal().getText(), beamIsOn);
        reload();    //reloads frame updates all of the components
    }

    public void stateChanged(ChangeEvent e){    //ChangeListener for sliders
        Object source = e.getSource();    //gets the source as there are 2 sliders
        int intVal = 0;    //intensity value from intensity slider
        if(source instanceof JSlider){    //checks if source is an instance of slider and is changed
        
            JSlider slider = (JSlider)source;    //casts the source which is of type Object into type JSlider
            String id = slider.getName();    //gets the name of slider, either Wavelenght or Intensity
            if("Wavelength".equals(id)){    //the changed sliderr is the wavelength slider       		
                                
                String valueStr = Integer.toString(slider.getValue());	//turns the value from slider to string
                view.getTextFieldVal().setText(valueStr);	//to set textfield the same as slider
                    setValues(valueStr, beamIsOn);//calulates and sets values of components, if beam is on
                    updateElectrons();
                
            }else if("Intensity".equals(id)){	//the changed slider is intensity slider
                intVal = slider.getValue();	//gets value and stores
                int n = intVal/100;

                if(intVal>0) {	//if intensity is greater than 0 then beam is on
                    beamIsOn = true;
                    
                    
                    try{
                    	electronStream.setPhotonsAmountCoeff(n);
                    	updatePaintElectron(view, n);
                    	updateElectrons();
                    }catch(Exception E) {
                    	//nothing
                    }
                    view.getTextFieldIntensity().setText(intVal+"");	//sets the intensity of textfield equal to slider
                    

                }else {	//beam is off
                	beamIsOn = false;
                	beamOff();
                }
                
            }
        }
        electronStream.checkBeam(beamIsOn);	//the PaintElectron class checks, will only pain if Beam is on
        
        reload();	//reloads frame with updated components

    }

    public void setValues(String value, boolean beamIsOn){	//this is the method that sets the values according to calculation
        reload();	//reloads frame and updated components

        if(beamIsOn == true && (metal.getProtonNumber() != -1 )){	//checks state of beam, and if a metal has been set determinde by rogue value        	
            
            thresholdFMet = false;	//initially false
            
            double wL =  Double.parseDouble(value);	//the string value is parsed into type double
            beam.setBeamWaveLength(wL);	//Beam class' wavelength is set, is converted into nm
            
            calc.setWaveLength(beam.getBeamWaveLength());	//Calculations class gets the Beam's wavelength

            double freq = calc.calculateFreqFromW(beam.getBeamWaveLength());	//calculates frequency of beam
            view.getTextFieldFreq().setText(freq+"");	//sets the textfield for frequency

            double pE = h.round(calc.getPhotonEnergyW(), 3);	//photon energy is calculated to 3 dp, and stored
            view.getTextFieldPhotonEnergy().setText(pE+"");		//sets the textfield for photon energy
            
            double workF = calc.getWorkF();		//gets the work function of  metal
            view.getTextFieldWorkF().setText(workF+"");		//sets the textfield for work function
            
            thresholdFMet = metal.thresholdFrequencyMet(calc.getPhotonEnergyW(), workF);	//calculates from the Metal class if treshold frequency is met
            

            electronStream.isthreshFreqMet(thresholdFMet);		//also notifies the PaintElectron class of this
            view.getTextFieldThresholdFMet().setText(thresholdFMet+"");

            if(thresholdFMet == true){	//threshold is met
            	//calculates and sets values accordingly
                double maxKE = calc.getPhotoElectronMaxKE();
                view.getTextFieldMaxKE().setText(maxKE+"");

                String maxVel = h.simplifyValueAsString(calc.getPhotoElectronVelocity(maxKE));	//velocity simplified and turn into string
                view.getTextFieldMaxVel().setText(maxVel+"");
                
                PhotoElectron peArray[] = electronStream.getPhotoElectronArray();	//gets the array of pe travelling
                for(PhotoElectron arrayE: peArray) {	//for every pe in array
                										//calculates values to be set to that single pe
                    double eCoeff = calc.generateEnergyCoeff();
                    double ke = calc.generatePhotoElectronKE(eCoeff, maxKE);
                    String vel = h.simplifyValueAsString(calc.getPhotoElectronVelocity(ke));	
                    Double velDbl = Double.parseDouble(vel);
                    double keV = h.round(ke/calc.getE(),3);
                    //sets the attributes of pe
                    if(ke == maxKE) {arrayE.setIsMaxKE(true);}
                	arrayE.setPhotoElectronKE(keV);
                	arrayE.setPhotoElectronVelocity(velDbl);
                	arrayE.setMoveSpeed(velDbl);
                }
                
            }else if(thresholdFMet==false){	//not met
            	threshFreqUnmet();	//sets values appropriately when thrshold is not met
            }
            
        }else if(beamIsOn == false) {	//beam is off 
        	view.getTextFieldPhotonEnergy().setText("0");
        	view.getTextFieldFreq().setText("0");
        	view.getTextFieldThresholdFMet().setText("false");
        	beamOff();	//sets values appropriately when beam is off
        	
        }else {	//metal has not been set
        	resetValues();
        }
    }
    
    public void updatePaintElectron(GUI gui, int n) {	//method to update the stream of electrons
		electronStream.setPhotonsAmountCoeff(n);
		electronStream.updatePaintElectron(gui);
    }
    
    public void updateElectrons() {
    	PhotoElectron[] peArray = electronStream.getPhotoElectronArray();
        for(PhotoElectron arrayE: peArray) {	//for every pe in array
        										//calculates values to be set to that single pe
        	try {
            double eCoeff = calc.generateEnergyCoeff();
            double maxKE = Integer.parseInt(view.getTextFieldMaxKE().getText());
            double ke = calc.generatePhotoElectronKE(eCoeff, maxKE);
            String vel = h.simplifyValueAsString(calc.getPhotoElectronVelocity(ke));	
            Double velDbl = Double.parseDouble(vel);
            double keV = h.round(ke/calc.getE(),3);
            //sets the attributes of pe
        	
        		if(ke == maxKE) {arrayE.setIsMaxKE(true);}
        		
        		arrayE.setPhotoElectronKE(keV);
        		arrayE.setPhotoElectronVelocity(velDbl);
        		arrayE.setMoveSpeed(velDbl);
        	}catch(Exception E) {}
        }
    }
    
    //methods to edit values according to circumstance
    public void threshFreqUnmet() {
        view.getTextFieldMaxKE().setText("");
        view.getTextFieldMaxVel().setText("");
        reload();
    	
    }
    
    public void beamOff() {
    	view.getTextFieldThresholdFMet().setText("");
    	view.getTextFieldPhotonEnergy().setText("");
        view.getTextFieldMaxKE().setText("");
        view.getTextFieldMaxVel().setText("");
        reload();
    }

    public void resetValues(){	//the default values, when reset button is clicked
        view.getSliderWaveLength().setValue(500);
        view.getSliderIntensity().setValue(0);
        view.getTextFieldIntensity().setText("");
        view.getTextFieldFreq().setText("");
        view.getTextFieldPhotonEnergy().setText("");
        view.getTextFieldWorkF().setText("");
        view.getTextFieldThresholdFMet().setText("");
        view.getTextFieldMaxKE().setText("");
        view.getTextFieldMaxVel().setText("");
        reload();
    }
    //sets up array
    public void setUpArray() {
    	String fileName;
    	File file = null;
    	Scanner inputStream;
    	List<List<String>> lines = null;
    	
    	try {
         fileName = "metals.txt";	//Metals.txt is a csv textfile
    	 file = new File(fileName);
    	 lines = new ArrayList<>();	//2darray list where all values from csv file is put in
    	
    
            inputStream = new Scanner(file);

            while(inputStream.hasNext()){
                String line= inputStream.next();
                String[] values = line.split(",");	//every , is a value
                // this adds the currently parsed line to the 2-dimensional string array
                lines.add(Arrays.asList(values));	//puts the acquired values into list
            }

            inputStream.close();
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        int rows = lines.size();
        int cols = lines.get(0).size();
        metalsArray = new String[lines.size()][lines.get(0).size()];	//2darray with equal dimensions as 2darray list
        for(int row = 0; row < rows; row++) {
            for(int col = 0; col < cols; col++) {
                metalsArray[row][col] = lines.get(row).get(col);	//puts values from 2darray list into metalsArray
            }
        }
    }
    //setting color of plate
    public Color setMetalColor(String c) {
    	Color clr = null;
    	if(c.equalsIgnoreCase("silver")) {
    		clr = Color.LIGHT_GRAY;
    	}else if(c.equalsIgnoreCase("white")) {
    		clr = Color.WHITE;
    	}else if(c.equalsIgnoreCase("gray")) {
    		clr = Color.GRAY;
    	}else if(c.equalsIgnoreCase("yellow")) {
    		clr = Color.YELLOW;
    	}
    	return clr;
    }
    
    public void reload() {
    	view.getElectronCanvas().removeAll();
    	view.revalidate();
    }

}
