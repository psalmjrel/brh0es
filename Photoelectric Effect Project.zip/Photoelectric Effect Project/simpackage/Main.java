package simpackage;
import javax.swing.JFrame;

/**
 *
 * @author (psalmjrel)
 */
public class Main{
	
    public static void main(String[] args) {
    	GUI frame = new GUI();
    	
    	frame.setVisible(true);
    	frame.setTitle("PhotoElectric Effect Simulation by psalmjrel");
    	frame.setExtendedState(JFrame.MAXIMIZED_BOTH);//sets default size of frame to be max size of screen
    	frame.setResizable(true);
    }

}
