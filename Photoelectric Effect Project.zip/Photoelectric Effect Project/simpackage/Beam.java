package simpackage;

/**
 * @author (psalmjrel)
 */
public class Beam {

    //default value for beam "turned off"
    private double frequency=0;
    private double wavelength=0;
    private double intensity=0;
    
   
    
    //default constructor
    public Beam() {
        
    }
    
    //getters and setter
    public void setBeamFrequency(double frequency) {
        this.frequency = frequency*Math.pow(10, 14);//beam frequency is usually to the power of 14
    }

    public double getBeamFrequency() {
        return this.frequency;
    }

    public void setBeamWaveLength(double wavelength) {
        this.wavelength = wavelength*Math.pow(10, -9);//wavelength in nanometers
    }

    public double getBeamWaveLength() {
        return this.wavelength;
    }

    public void setBeamIntensity(double intensity) {
        this.intensity = intensity;
    }

    public double getBeamIntensity() {
        return this.intensity;
    }

    public String displayDetailsBeam() {
        return "Frequency(Hz): " + frequency + "\nWavelength(nm): " + wavelength + "\nIntensity: " + intensity;
    }

}
