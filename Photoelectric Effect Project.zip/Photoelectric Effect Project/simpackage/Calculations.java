package simpackage;
/**
 * @author (psalmjrel)
 */

public class Calculations {
    private final double c = 2.99792458 * (Math.pow(10, 8));    //the speed of light constant
    private final double h = 6.62607004 * (Math.pow(10, -34));    //the Planck's Constant
    private final double e = 1.6022 * (Math.pow(10, -19));    //the 
    private final double eMass = 9.10938356 * (Math.pow(10, -31));    //the mass of an Electron

    private double frequency;    //frequency of beam
    private double wavelength;    //wavelength of beam
    private double threshF;    //threshold frequency of metalplate
    private double intensity;    //intensity of beam

    private double energyCoeff;    // energyCoeff of photoelectron
    private double photonEnergy;    //energy of photon
    private double MaxKE;    //the maximum kinetic energy of photoelectron


    private Metal metal;
    private Beam beam;


    public Calculations(Beam mainBeam) {
        this.wavelength = mainBeam.getBeamWaveLength();
        this.frequency = mainBeam.getBeamFrequency();
        this.intensity = mainBeam.getBeamIntensity();;
    }
    
        //SETTERS and GETTERS
    public double getC() {
        return this.c;
    }

    public double getE() {
        return this.e;
    }

    public double getH() {
        return this.h;
    }

    public void setFrequency(double frequency) {
        this.frequency = frequency;
    }

    public double getFrequency() {
        return this.frequency;
    }
        //calculate frequency of beam from a given wavelength
    public double calculateFreqFromW(double w) {
        
        double result = c/w;    //from speed of light formula

        return result;

    }

    public void setWaveLength(double wavelength) {
        this.wavelength = wavelength;
    }

    public double getWaveLength() {
        this.wavelength = beam.getBeamWaveLength();
        return this.wavelength;
    }

        // public String calculateWaveFromF(double f){
        // return c/f;
        // }

    public void setBeamIntensity(double intensityLevel) {
        this.intensity = intensityLevel;
    }

    public double getBeamIntensity() {
        return this.intensity;
    }
    
    
        //calculate photon energy when Frequency is known
    public double getPhotonEnergyF() {
        this.photonEnergy = (h * frequency) / e;
        return this.photonEnergy;
    }
    
        //and when Wavelength is known
    public double getPhotonEnergyW() {
        double f = (c / this.wavelength);
        this.photonEnergy = (h * f) / e;
        return this.photonEnergy;
    }
    
        //randomly generate a number to multiply to the max kinetic energy for photoelectron
        //electrons are randomly oriented and placed in the metal in different ways, hence different energies
    
    public double generateEnergyCoeff() {
        boolean found = false;
        while (!found) {
            double n = Math.random();
            Handler h = new Handler();
            n = h.round(n, 2);
            if (n > 0.00) {
                if (n == 0.99) {
                    this.energyCoeff = n + 0.01;
                    found = true;
                    return energyCoeff;
                }
                this.energyCoeff = n;
                found = true;
            } else {
                found = false;
            }
        }
        return energyCoeff;
    }
    
        //calculates photoelectron's maximum kinetic energy
    public double getPhotoElectronMaxKE() {
        double f = (c / this.wavelength);
        this.MaxKE = (h * f) - (metal.getMetalWorkF() * e);
        return this.MaxKE;
    }
    
        //calculates current photoelectron's kinetic energy
    public double generatePhotoElectronKE(double e, double maxKE) {
        double ke = e*maxKE;
        return ke;
    }

    
        //calculates photoelectron's velocity
    public double getPhotoElectronVelocity(double peKE) {
        if (peKE > 0) {
            double vSq = (2 * (peKE)) / (eMass);
            return Math.sqrt(vSq);
        } else {
            return 0.00;
        }
    }

    public void setMetal(Metal metal) {
        this.metal = metal;
    }

    public Metal getMetal() {
        return this.metal;
    }

    public double getWorkF() {
        return metal.getMetalWorkF();
    }

    public double getThresholdFreq() {
        this.threshF = (metal.getMetalWorkF() * e) / h;
        return this.threshF;
    }
}
