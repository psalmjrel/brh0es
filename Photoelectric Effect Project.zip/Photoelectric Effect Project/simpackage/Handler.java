package simpackage;
import java.text.DecimalFormat;
/**
 * @author (psalmjrel)
 */
public class Handler
{
   
    /**
     * Constructor for objects of class b
     */
    public Handler()
    {
        // empty constructor
    }
    
    //rounds the val perimiter to the nearest precision decimal point
    public double round(double val, int precision) {
        int scale = (int) Math.pow(10, precision);
        return (double) Math.round(val * scale) / scale;
    }
    
    //simplifies value and turn into string
    public String simplifyValueAsString(double valIn){
        double val = valIn;
        DecimalFormat df = new DecimalFormat("###0.00");
        String valAsString = df.format(val);
        return valAsString;
    }
    

}
