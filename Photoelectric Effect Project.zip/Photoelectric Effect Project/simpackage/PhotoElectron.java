package simpackage;
import java.util.Random;
import java.awt.*;
import javax.swing.*;
/**
 * @author (psalmjrel)
 * @version (12/09)
 */

public class PhotoElectron extends JButton {

	private boolean paused;
	private boolean isMaxKE = false;
	
    private final int OVAL_RADIUS = 12; //radius of electron
    
    private final Color color = new Color(100, 210, 220);	//color of electron
    private int iniX = 0;	//initial x coordinate of electron
    private int locationY;	//location y of electron
    private int locationX = -OVAL_RADIUS;	
    private int moveSpeed;	//travel speed of electron
    
    private double photoElectronKE;// kinetic energy
    private double photoElectronV;// actual calculated velocity
    
    private Random r = new Random();
    
    
    public PhotoElectron() {	//constructor
    	setButtonRound();	//creates round buttons to represetn photoelectrons
    	generateRandomYLocation();	//randomly places electron on surface of metal
    }
    //GETTERS & SETTER

    public int getOvalRadius(){
        return OVAL_RADIUS;
    }
    

    public void setPhotoElectronKE(double ke){
        this.photoElectronKE = ke;   
    }

    public double getPhotoElectronKE(){
        return this.photoElectronKE;
    }
    

    public void setPhotoElectronVelocity(double vel){
        this.photoElectronV = vel;
    }

    public double getPhotoElectronVelocity() {
        return this.photoElectronV;
    }
    
    public void setIsMaxKE(boolean b) {	//does this photoelectron have max KE
    	this.isMaxKE = b;
    }
    
    public boolean getIsMaxKE() {
    	return this.isMaxKE;
    }
    
    public int generateRandomYLocation(){	//photoelectrons are painted along the height of metal plate
        return locationY = r.nextInt(700);
    }
    
    
    public void setMoveSpeed(double s) {	//parameter s is the velocity of electron
    	moveSpeed = 0; //resets moveSpeed
    	if(photoElectronKE == 0.000) {
    		moveSpeed = 0;
    	}
    	moveSpeed = (int)s/15000;
    }
    
    public void setAnimationState(boolean p) {	//checks if paused
    	this.paused = p;
    }
    
    public void create(JPanel p){	//paint method
        int width;	//max distance electrons can travel before they are absorbed my positive plate

        width = p.getWidth();	//gets the gui's canvaspanel's width    
        p.setBackground(Color.WHITE);
        movePhotoElectron(width);
        
        this.setBounds(locationX, locationY, OVAL_RADIUS, OVAL_RADIUS);
        this.setToolTipText(this.Inspect()); //user can hover over this photoelectron and will display details
        p.add(this);//paints and sets location
        iniX = locationX;
    }
    
    public void movePhotoElectron(int w) {
        if(paused == false) {
        	locationX = iniX + moveSpeed;	//moves x coord

        	if(locationX > w+OVAL_RADIUS){	//at the edge
        		generateRandomYLocation();	//generates new loaction, and speed
        		locationX = -OVAL_RADIUS;	//starts at beginning
        	}
        }
        
    }
    
    public void setButtonRound() {
        Dimension size = getPreferredSize();
        size.width = size.height = Math.max(size.width, size.height);	//buttons becomes a circle with equal radius, not an oval
        setPreferredSize(size);
        this.setEnabled(false);
        this.setBackground(color);	//color of electron
        this.setFocusable(false);
        this.setContentAreaFilled(false);	//does not paint background of button, we paint a round backround instead
    }
    
	protected void paintComponent(Graphics g) {	//paints round background
	    if (getModel().isArmed()) {
	      g.setColor(color);
	    } else {
	      g.setColor(getBackground());
	    }
	    g.fillOval(0, 0, getSize().width - 1, getSize().height - 1);	//round background with the same dimension as pe
	 
	    super.paintComponent(g);
	  }
	 
		protected void paintBorder(Graphics g) {	//black border
	    g.setColor(Color.BLACK);
	    g.drawOval(0, 0, getSize().width - 1, getSize().height - 1);
	  }
    
    public String Inspect() {
        return "[Kinetic Energy(eV): "+photoElectronKE+", Velocity(m/s): "+photoElectronV +",  MAX KE: "+isMaxKE+", MS: "+moveSpeed+"]";
    }

}
