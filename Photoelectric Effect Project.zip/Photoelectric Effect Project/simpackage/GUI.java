package simpackage;
import javax.swing.*;
import java.awt.*;
import java.util.*;
/**
 * @author (psalmjrel)
 */
public class GUI extends JFrame 
{
        // instance variables
    
    private JLabel lblVal, lblFreq, lblIntensity, lblWaveLength, lblPhotonEnergy,lblWorkF, lblThresholdFMet, lblMaxKE, 
    				lblMaxVel, metalPlateLbl;

    private JButton resetBtn, offButton, intensityLvlOne, intensityLvlTwo, intensityLvlThree,
    				metalPlateBtn, positivePlateBtn, pauseBtn, resumeBtn;
    private JSlider sliderWaveLength, sliderIntensity;
    private JTextField tfVal, tfIntensity, tfFreq, tfPhotonEnergy, tfWorkF, tfThresholdFMet, tfMaxKE,
    				 tfMaxVel;
    private JComboBox<?> cbMetal;
    private Container contentPane;
    private JPanel canvasPanel;
    private JPanel upperCanvasPanel, middleCanvasPanel, electronCanvas, lowerCanvasPanel, sidePanel, controlPanel;

    private String[] metalsArray = {null,"Silver","Sodium", "Potassium", "Rubidium", "Cesium", "Calcium", 
    								"Barium", "Zinc", "Aluminium", "Gallium", "Tin", "Lead", "Tungsten",
    								"Titanium", "Chromium", "Iron", "Nickel", "Gold", "Platinium", "Magnesium" };	//array initialised for combo box
    
    private Metal metal = new Metal();	//default metal null
    

	public GUI() {
    	JPanel miniPanel = new JPanel(new GridLayout(0, 2, 2, 2));	//panel that will hold the intensity buttons and JComboBox
    	JPanel intensityButtonsPanel = new JPanel(new GridLayout(5, 0, 2, 2));
    	JPanel metalsComboBoxPanel = new JPanel(new GridLayout(2, 0, 2, 2));
    	JPanel panelPauseResume = new JPanel();
    	
    	
    	
    	
    	
        contentPane = getContentPane();    //stores the container to be able to add
        							      //components in it through nested panels
        
        contentPane.setLayout(new BorderLayout(10, 0));    //sets layout to border layout

        sidePanel = new JPanel();    //the side panel is the main panel of where the controls component will be added
        sidePanel.setLayout(new BorderLayout());    //with a borderlayout


        controlPanel = new JPanel();    //will be nested on top of the side panel
        controlPanel.setBorder(BorderFactory.createTitledBorder("Controls & Information:"));
        controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));    //box layout, component added will vertically flow
        controlPanel.setBackground(Color.CYAN);

        lblWaveLength = new JLabel("Set Wavelength(nm):");
        controlPanel.add(lblWaveLength);

        sliderWaveLength = new JSlider(100, 900, 500);    //initialises slider for changing wavelength
        sliderWaveLength.setName("Wavelength");    //sets unique name so Controller can deal with sliders seperately
        sliderWaveLength.setMajorTickSpacing(100);    //every 100 is marked
        sliderWaveLength.setMinorTickSpacing(20);    //every 20 is marked, smaller
        sliderWaveLength.setPaintTicks(true);
        //sliderWaveLength.setEnabled(false);

        Hashtable<Integer, JLabel> position = new Hashtable<Integer, JLabel>();
        position.put(379, new JLabel("UV"));    //add labels, 379nm below is ultra violet
        position.put(780, new JLabel("IR"));    //780nm and above is IR, between them is VL
        sliderWaveLength.setLabelTable(position);    //adds labels ot the slider
        sliderWaveLength.setPaintLabels(true);    //shows marks
        controlPanel.add(sliderWaveLength);    //adds component to control panel

        lblIntensity = new JLabel("Set Intensity(%):");
        controlPanel.add(lblIntensity);

        sliderIntensity = new JSlider(0, 300, 0);    //slider to set intensity of beam
        sliderIntensity.setName("Intensity");    //sets unique name so Controller can deal with sliders seperately
        sliderIntensity.setMajorTickSpacing(100);    //every 100 is marked
        sliderIntensity.setMinorTickSpacing(50);    //every 50 is marked, smaller
        sliderIntensity.setPaintTicks(true);

        Hashtable<Integer, JLabel> intensityPos = new Hashtable<Integer, JLabel>();
        intensityPos.put(100, new JLabel("100%"));
        intensityPos.put(200, new JLabel("200%"));
        intensityPos.put(300, new JLabel("300%"));
        sliderIntensity.setLabelTable(intensityPos);
        sliderIntensity.setPaintLabels(true);    //shows marks
        sliderIntensity.setEnabled(false);
        controlPanel.add(sliderIntensity);
        
        
        
        JLabel btnLabel = new JLabel("Set Intensity:");//buttons to set intensity
        intensityButtonsPanel.add(btnLabel);
        offButton = new JButton("Off.");    //sets intenisty to 0% or off
        intensityButtonsPanel.add(offButton);
        intensityLvlOne = new JButton("100%");    //sets to 100%
        intensityButtonsPanel.add(intensityLvlOne);
        intensityLvlTwo = new JButton("200%");    //to 200%
        intensityButtonsPanel.add(intensityLvlTwo);
        intensityLvlThree = new JButton("300%");    // to 300%
        intensityButtonsPanel.add(intensityLvlThree);
        
        JLabel cbLabel = new JLabel("Select Metal: ");	
        metalsComboBoxPanel.add(cbLabel);
        cbMetal = new JComboBox(metalsArray);	//combo box, user will select what elemnt is the metal plate
        metalsComboBoxPanel.add(cbMetal);
        
        miniPanel.add(intensityButtonsPanel);
        miniPanel.add(metalsComboBoxPanel);
        controlPanel.add(miniPanel);
        
            //these components are going to be the results after changing values from the above components
        lblVal = new JLabel("Value(nm): ");
        controlPanel.add(lblVal);
        tfVal = new JTextField(15);
        tfVal.setText(sliderWaveLength.getValue()+"");
        tfVal.setEditable(true);
        controlPanel.add(tfVal);

        lblIntensity = new JLabel("Intensity(%):");
        controlPanel.add(lblIntensity);
        tfIntensity = new JTextField(15);
        tfIntensity.setText(sliderIntensity.getValue()+ "");
        tfIntensity.setEditable(false);
        controlPanel.add(tfIntensity);

        lblFreq = new JLabel("Frequency(Hz):");
        controlPanel.add(lblFreq);
        tfFreq = new JTextField(15);
        tfFreq.setEditable(false);
        controlPanel.add(tfFreq);

        lblPhotonEnergy = new JLabel("Photon Energy(eV):");
        controlPanel.add(lblPhotonEnergy);
        tfPhotonEnergy = new JTextField(15);
        tfPhotonEnergy.setEditable(false);
        controlPanel.add(tfPhotonEnergy);

        lblWorkF = new JLabel("Work Function of Metal(eV):");
        controlPanel.add(lblWorkF);
        tfWorkF = new JTextField(15);
        tfWorkF.setEditable(false);
        controlPanel.add(tfWorkF);

        lblThresholdFMet = new JLabel("Threshold Frequency Met:");
        controlPanel.add(lblThresholdFMet);
        tfThresholdFMet = new JTextField(15);
        tfThresholdFMet.setEditable(false);
        controlPanel.add(tfThresholdFMet);

        lblMaxKE = new JLabel("Maximum KE(J):");
        controlPanel.add(lblMaxKE);
        tfMaxKE = new JTextField(15);
        tfMaxKE.setEditable(false);
        controlPanel.add(tfMaxKE);

        lblMaxVel = new JLabel("Electron's MAX Velocity(m/s):");
        controlPanel.add(lblMaxVel);
        tfMaxVel = new JTextField(15);
        tfMaxVel.setEditable(false);
        controlPanel.add(tfMaxVel);
        
            // reset btn will reset values to default and set components to blank
        resetBtn = new JButton("RESET");
        pauseBtn = new JButton("PAUSE");
        resumeBtn = new JButton("RESUME");
        panelPauseResume.setLayout(new GridLayout(0,3));
        panelPauseResume.setBackground(Color.WHITE);
        panelPauseResume.add(pauseBtn);
        panelPauseResume.add(resetBtn);
        panelPauseResume.add(resumeBtn);
        controlPanel.add(panelPauseResume);

        sidePanel.add(controlPanel, BorderLayout.NORTH);    //adds all of those components onto the north of sidePanel
        
            //the left side of the gui is divided evenly into three parts
        upperCanvasPanel = new JPanel();    //an upper canvas
        upperCanvasPanel.setBackground(Color.WHITE);       
        
        lowerCanvasPanel = new JPanel();    //lower canvas
        lowerCanvasPanel.setBackground(Color.WHITE);
        lowerCanvasPanel.setLayout(new GridLayout(0, 3));
        
            //INITIATES THE STREAM OF ELECTRONS INTO THIS GUI
        //electronStream = new PaintElectron(this);


        electronCanvas = new JPanel(new BorderLayout());    //an electron canvas which will be added ONTO MIDDLE CANVAS
        electronCanvas.setBackground(Color.WHITE);    //will be the component in which the photoelectrons travel on
        //electronCanvas.add(electronStream, BorderLayout.CENTER);    //adds the stream of electron to this space
        
        metalPlateBtn = new JButton() {
        	
        	@Override
        	public JToolTip createToolTip() {
        		JVerticalToolTip tip = new JVerticalToolTip(180, 120);
        		tip.setComponent(this);
        		return tip;
        	}
        };	//JVericalToolTip is a user defined class to display tool tips in a format of a Text Area
        	
        
        metalPlateLbl = new JLabel();
        metalPlateLbl.setForeground(Color.BLUE);
        metalPlateBtn.add(metalPlateLbl);
        metalPlateBtn.setBackground(metal.getColour());
        metalPlateBtn.setToolTipText(metal.toString());	//tool tip is the attributes of the metal
        metalPlateBtn.setEnabled(false);
        
        positivePlateBtn = new JButton();    //same thing for the positive plate the electrons will arrive on
        JLabel positiveLbl = new JLabel("Positive Plate");    //to be able to change font and colour of button label
        positiveLbl.setForeground(Color.BLUE);
        positivePlateBtn.add(positiveLbl);
        positivePlateBtn.setBackground(Color.LIGHT_GRAY);
        positivePlateBtn.setEnabled(false);    //false, has no purpose to be clicked
        
        middleCanvasPanel = new JPanel(new BorderLayout());    //the middle canvas panel
        middleCanvasPanel.setBackground(Color.WHITE);
        middleCanvasPanel.add(metalPlateBtn, BorderLayout.WEST);    //photoelectrons begin from west of canvas
        middleCanvasPanel.add(positivePlateBtn, BorderLayout.EAST);    //arrives at east of canvas
        middleCanvasPanel.setBorder(BorderFactory.createTitledBorder("Photoelectrons:"));    //sets a border around the space
        middleCanvasPanel.add(electronCanvas);    //the electron canvas is added on top of the middle panel

        canvasPanel = new JPanel();    //the main canvas on the left side of the entire frame
        canvasPanel.setLayout(new GridLayout(3,0));    //has grid layout, 3 equal rows going down
        canvasPanel.add(upperCanvasPanel);    //upper canvasgoes on top
        canvasPanel.add(middleCanvasPanel);    //middle canvas goes on middle
        canvasPanel.add(lowerCanvasPanel);    //lower
        canvasPanel.setBackground(Color.WHITE);

          //adds all the components into the main container
        contentPane.add(sidePanel, BorderLayout.EAST);    //adds the side panel with the controls to the right side
        contentPane.add(canvasPanel, BorderLayout.CENTER);    //adds the moving photoelectrons to the left side
       
        Controller c = new Controller(this, metal);
            //components are added listeners from the Controller class
        sliderWaveLength.addChangeListener(c);
        sliderIntensity.addChangeListener(c);
        
        tfVal.addActionListener(c);
        resetBtn.addActionListener(c);
        pauseBtn.addActionListener(c);
        resumeBtn.addActionListener(c);
        offButton.addActionListener(c);
        intensityLvlOne.addActionListener(c);
        intensityLvlTwo.addActionListener(c);
        intensityLvlTwo.addActionListener(c);
        intensityLvlThree.addActionListener(c);
        cbMetal.addActionListener(c);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
    }
	
	public Metal getMetal() {
		return metal;
	}
	
	public void setMetal(Metal m) {
		this.metal = m;
	}
	
	public JComboBox<?> getComboBox() {
		return cbMetal;
	}
    
        //return the electronStream
	
    //public PaintElectron getElectronStream() {
    	//return electronStream;
    //}
        //returns the main canvasPanel
    public JPanel getCanvasPanel() {
    	return canvasPanel;
    }
        //returns upper canvas
    public JPanel getUpperCanvasPanel() {
    	return upperCanvasPanel;
    }
        //returns middle canvas
    public JPanel getMiddleCanvasPanel() {
    	return middleCanvasPanel;
    }
        //returns lower canvas
    public JPanel getLowerCanvasPanel() {
    	return lowerCanvasPanel;
    }
        //returns the canvas where photoelectrons are travelling
    public JPanel getElectronCanvas() {
    	return electronCanvas;
    }
        //return width of canvas panel, the max distance a photoelectron can travel
    public int getCanvasPanelWidth(){
        return canvasPanel.getWidth();
    }
        //returns height of canvas panel, photoelectrons emit from random heights of plate
    public int getCanvasPanelHeight() {
    	return canvasPanel.getHeight();
    }
    
        //returns wavelength slider
    public JSlider getSliderWaveLength(){
        return sliderWaveLength;
    }
        //returns intensity slider
    public JSlider getSliderIntensity(){
        return sliderIntensity;
    }
    
        //returns  these components to allow the controller to have access to these copmonents
        //set them depending on the results of calculations
    public JTextField getTextFieldVal(){
        return tfVal;
    }

    public JTextField getTextFieldIntensity(){
        return tfIntensity;
    }

    public JTextField getTextFieldFreq(){
        return tfFreq;
    }

    public JTextField getTextFieldPhotonEnergy(){
        return tfPhotonEnergy;
    }

    public JTextField getTextFieldWorkF(){
        return tfWorkF;
    }

    public JTextField getTextFieldThresholdFMet(){
        return tfThresholdFMet;
    }

    public JTextField getTextFieldMaxKE(){
        return tfMaxKE;
    }


    public JTextField getTextFieldMaxVel(){
        return tfMaxVel;
    }

    
    public JButton getMetalPlateBtn() {
    	return metalPlateBtn;
    }
    
    public JButton getPauseButton() {
    	return pauseBtn;
    }
    
    public JButton getResumeButton() {
    	return resumeBtn;
    }
    
    public JLabel getMetalPlateLbl() {
    	return metalPlateLbl;
    }
   
}
